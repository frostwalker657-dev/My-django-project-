# Prophet Mugisha Bosco Ministries — Website (Prototype)

Official website project for **Prophet Mugisha Bosco Ministries** and
**Wholistic Church of All Nations** — Busoro, Kabarole, Fort Portal City, Western Uganda.

## Current stage
Foundation + homepage hero + all page routes with truthful
"coming soon" placeholders. No invented information is published.

## Run it locally

```bash
# 1. Create a virtual environment
python -m venv venv

# 2. Activate it
# Windows:
venv\Scripts\activate
# Mac/Linux:
source venv/bin/activate

# 3. Install Django
pip install -r requirements.txt

# 4. (first time only) create the database
python manage.py migrate

# 5. Run the development server
python manage.py runserver
```

Open http://127.0.0.1:8000 in your browser.

The Sermons page is a full library: instant client-side search (no page
reloads, no extra API cost) plus topic and year filter chips. Topic tags
are auto-detected from sermon titles for now; admin-assigned categories
arrive with the Phase 6 backend.

## Enable live YouTube sermons (recommended)

The homepage **Featured Sermon** and **Latest Sermons** sections, and the
whole Sermons page, pull the latest videos automatically from the
ministry's official YouTube channel (@prophetmugishaministries8162)
using the official YouTube Data API v3.

**How to get a free API key (about 10 minutes):**

1. Go to https://console.cloud.google.com and sign in with a Google account
2. Create a new project (e.g. "PMBM Website")
3. Open **APIs & Services > Library**, search for **YouTube Data API v3**, and enable it
4. Go to **APIs & Services > Credentials**, click **Create Credentials > API key**
5. Open `config/settings.py` and paste the key:
   `YOUTUBE_API_KEY = "your-key-here"`
6. Restart the server — sermons appear automatically and update themselves

**Until a key is added, the site shows the professional "coming soon"
state — nothing breaks.**

Cost: the API's free quota is 10,000 units per day. Responses are cached
for 6 hours, so this website uses only a few units per day — effectively free.

## Project structure

```
config/     Django project settings and root URLs
core/       All public pages (views, urls, templates)
templates/  base.html — shared header, navigation and footer
static/     css/style.css — visual identity (navy + gold, mobile-first)
```

## Roadmap (from the project plan)
1. Website architecture — DONE
2. Visual identity + homepage — IN PROGRESS
3. Full homepage sections (services, sermons, prayer CTA, events, ...)
4. Mobile responsiveness checks
5. YouTube/media integration
6. Backend/database (sermons, events, prayer requests)
7. Admin dashboard
8. Prayer-request system
9. Events management
10. Giving integration
11. Real ministry content integration
12. Testing & security
13. Ministry approval
14. Public launch

## Content rules
- Never invent missing information.
- Use "Coming soon" / "To be provided" placeholders.
- No personal biography of Prophet Mugisha Bosco at this stage.
- No personal photograph until officially provided and approved.
- Only verified official social media accounts may be linked.
- Do not invent payment details.

## Before public launch
- Change `SECRET_KEY` in `config/settings.py`
- Set `DEBUG = False`
- Add the real domain to `ALLOWED_HOSTS`
- Create real Privacy Policy and Terms of Use pages
