from django.db import models

# Phase 6 (backend/database): Sermon, Event, PrayerRequest, etc.
# will be defined here.
