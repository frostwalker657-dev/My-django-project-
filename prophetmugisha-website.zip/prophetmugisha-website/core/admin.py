from django.contrib import admin

# Phase 6/7: register Sermon, Event, PrayerRequest models here
# once the backend is built.
