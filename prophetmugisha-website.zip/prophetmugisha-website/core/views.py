from django.shortcuts import render

from .youtube import TAG_LABELS, get_latest_sermons


def home(request):
    videos = get_latest_sermons(limit=4)
    return render(
        request,
        "core/home.html",
        {
            "featured_sermon": videos[0] if videos else None,
            "latest_sermons": videos[1:4],
        },
    )


def about(request):
    return render(request, "core/about.html")


def sermons(request):
    # Fetch up to 50 so the library can search/filter client-side (still just
    # 1 API unit, cached 6 hours). Instant search needs no extra API calls.
    videos = get_latest_sermons(limit=50)
    tags = sorted({tag for v in videos for tag in v["tags"]})
    tag_chips = [(t, TAG_LABELS.get(t, t.replace("-", " ").title())) for t in tags]
    years = sorted({v["year"] for v in videos}, reverse=True)
    return render(
        request,
        "core/sermons.html",
        {
            "featured_sermon": videos[0] if videos else None,
            "sermons": videos,
            "tag_chips": tag_chips,
            "years": years,
        }
    )


def prayer(request):
    return render(request, "core/prayer.html")


def events(request):
    return render(request, "core/events.html")


def find_us(request):
    return render(request, "core/find_us.html")


def contact(request):
    return render(request, "core/contact.html")


def give(request):
    return render(request, "core/give.html")


def media(request):
    return render(request, "core/media.html")
