from django.urls import path
from . import views

urlpatterns = [
    path("", views.home, name="home"),
    path("about/", views.about, name="about"),
    path("sermons/", views.sermons, name="sermons"),
    path("prayer/", views.prayer, name="prayer"),
    path("events/", views.events, name="events"),
    path("find-us/", views.find_us, name="find_us"),
    path("contact/", views.contact, name="contact"),
    path("give/", views.give, name="give"),
    path("media/", views.media, name="media"),
]
