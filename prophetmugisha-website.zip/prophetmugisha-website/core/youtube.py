"""
YouTube Data API v3 integration.

Fetches the latest videos from the ministry's official YouTube channel
and returns them as plain dictionaries for the templates.

Design rules:
- If no API key is configured -> returns [] (templates show "coming soon")
- If the API is unreachable -> returns [] (site never crashes)
- Results are cached for 6 hours (free quota is 10,000 units/day;
  this site uses only a few per day)
"""

from datetime import datetime

import requests
from django.conf import settings
from django.core.cache import cache

API_BASE = "https://www.googleapis.com/youtube/v3"

# Auto-tagging rules: a sermon gets a tag if its title contains a keyword.
# (Phase 6 will replace this with proper admin-assigned categories.)
TAG_KEYWORDS = {
    "prophecies": ("prophecy", "prophesy", "prophetic"),
    "sunday-service": ("sunday service", "sunday"),
    "crusades": ("crusade",),
    "teachings": ("teaching", "bible study", "the word", "sermon"),
}

TAG_LABELS = {
    "prophecies": "Prophecies",
    "sunday-service": "Sunday Service",
    "crusades": "Crusades",
    "teachings": "Teachings",
}


def _auto_tags(title):
    t = title.lower()
    return [tag for tag, words in TAG_KEYWORDS.items() if any(w in t for w in words)]


def _channel_uploads_playlist_id(api_key):
    """Resolve the channel handle to its 'uploads' playlist ID."""
    response = requests.get(
        f"{API_BASE}/channels",
        params={
            "part": "contentDetails",
            "forHandle": settings.YOUTUBE_CHANNEL_HANDLE,
            "key": api_key,
        },
        timeout=10,
    )
    response.raise_for_status()
    items = response.json().get("items", [])
    if not items:
        return None
    return items[0]["contentDetails"]["relatedPlaylists"]["uploads"]


def _fetch_uploads(api_key, playlist_id, limit):
    """Fetch the most recent videos from the uploads playlist."""
    response = requests.get(
        f"{API_BASE}/playlistItems",
        params={
            "part": "snippet,contentDetails",
            "playlistId": playlist_id,
            "maxResults": limit,
            "order": "date",
            "key": api_key,
        },
        timeout=10,
    )
    response.raise_for_status()

    videos = []
    for item in response.json().get("items", []):
        snippet = item["snippet"]
        if snippet.get("resourceId", {}).get("videoId") is None:
            continue  # skip private/deleted videos
        video_id = snippet["resourceId"]["videoId"]
        thumbs = snippet.get("thumbnails", {})
        thumb = thumbs.get("medium") or thumbs.get("default") or {}
        videos.append(
            {
                "video_id": video_id,
                "title": snippet["title"],
                "description": snippet.get("description", ""),
                "published_at": datetime.fromisoformat(
                    snippet["publishedAt"].replace("Z", "+00:00")
                ),
                "thumbnail": thumb.get("url", ""),
                "tags": _auto_tags(snippet["title"]),
                "year": int(snippet["publishedAt"][:4]),
                "url": f"https://www.youtube.com/watch?v={video_id}",
                "embed_url": f"https://www.youtube.com/embed/{video_id}",
            }
        )
    return videos


def get_latest_sermons(limit=12):
    """Return the latest videos from the ministry's YouTube channel.

    Always returns a list (empty when unavailable) so templates can
    fall back to the "coming soon" state gracefully.
    """
    api_key = getattr(settings, "YOUTUBE_API_KEY", "")
    if not api_key:
        return []

    cache_key = f"youtube_latest_{limit}"
    cached = cache.get(cache_key)
    if cached is not None:
        return cached

    try:
        playlist_id = _channel_uploads_playlist_id(api_key)
        if not playlist_id:
            return []
        videos = _fetch_uploads(api_key, playlist_id, limit)
    except Exception:
        # API down, quota exceeded, network issue -> graceful fallback
        return []

    cache.set(cache_key, videos, 60 * 60 * 6)  # 6 hours
    return videos
